1.6.0.0_CT

germany-G141_VK7501K
germany-G142_M48RPz
germany-G143_E75_TS 

uk-GB100_Manticore
uk-GB101_FV1066_Senlac
uk-GB102_LHMTV
uk-GB103_GSOR3301_AVR_FS
uk-GB104_GSR_3301_Setter
uk-GB105_Black_Prince_2019

usa-A124_T54E2
usa-A125_AEP_1
usa-A127_TL_1_LPC

ussr-R119_Object_777C